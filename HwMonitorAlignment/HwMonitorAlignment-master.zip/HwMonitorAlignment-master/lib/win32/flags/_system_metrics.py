import enum


class SystemMetricsFlags(enum.IntEnum):
    XVIRTUALSCREEN = 76
    YVIRTUALSCREEN = 77

    CXVIRTUALSCREEN = 78
    CYVIRTUALSCREEN = 79
