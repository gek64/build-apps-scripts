import enum


class MonitorInfoFlags(enum.IntFlag):
    PRIMARY = 0x00000001
