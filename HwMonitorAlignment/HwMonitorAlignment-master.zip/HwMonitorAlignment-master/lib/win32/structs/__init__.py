from lib.win32.structs._devmode import DEVMODE
from lib.win32.structs._display_device import *
from lib.win32.structs._displayconfig import *
from lib.win32.structs._monitorinfo import *
