__name__ = 'HwMonitorAlignment'
__version__ = '1.0.0'
__description__ = "HwMonitorAlignment is a tool to align your multi-monitor setup perfectly in Windows."
__website__ = 'http://gitlab.chrisware.de/chris/hwmonitoralignment'
